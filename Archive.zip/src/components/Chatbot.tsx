import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MessageCircle, X, Send, Bot, User } from "lucide-react";

interface Message {
  id: string;
  sender: "user" | "bot";
  content: string;
  timestamp: Date;
}

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "bot",
      content: "Hi! I'm your CivicReport assistant. I can help you report issues, track your submissions, or answer questions about civic services. How can I help you today?",
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState("");

  const quickReplies = [
    "How do I report an issue?",
    "Track my report",
    "What types of issues can I report?",
    "How long does resolution take?"
  ];

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      sender: "user",
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");

    // Simulate bot response
    setTimeout(() => {
      const botResponse = getBotResponse(inputValue);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "bot",
        content: botResponse,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  const getBotResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes("report") || input.includes("issue")) {
      return "To report an issue: 1) Click 'Report Issue' button, 2) Select the issue category, 3) Add photos and location, 4) Submit! You'll get a tracking ID to monitor progress.";
    } else if (input.includes("track")) {
      return "You can track your reports by clicking on 'Track Progress' in the navigation. Enter your report ID (e.g., #CIV-2024-001) to see real-time status updates.";
    } else if (input.includes("types") || input.includes("what")) {
      return "You can report: Potholes & road damage, streetlight issues, garbage problems, graffiti, sidewalk issues, traffic signal problems, parks maintenance, and more!";
    } else if (input.includes("time") || input.includes("long")) {
      return "Response times vary by issue type: Urgent issues (24hrs), High priority (3-5 days), Medium priority (1-2 weeks), Low priority (2-4 weeks). You'll get notifications for all updates!";
    } else {
      return "I'm here to help with reporting civic issues and tracking progress. You can ask me about the reporting process, tracking submissions, or civic services in general. What would you like to know?";
    }
  };

  const handleQuickReply = (reply: string) => {
    setInputValue(reply);
    handleSendMessage();
  };

  return (
    <>
      {/* Chat Toggle Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-lg transition-all duration-300 ${
          isOpen ? 'bg-muted hover:bg-muted/80' : 'bg-primary hover:bg-primary-hover'
        } ${isOpen ? 'rotate-180' : 'animate-bounce-soft'}`}
      >
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <MessageCircle className="w-6 h-6" />
        )}
      </Button>

      {/* Chat Panel */}
      {isOpen && (
        <Card className="fixed bottom-24 right-6 z-40 w-80 h-96 shadow-xl animate-scale-in">
          <CardContent className="p-0 h-full flex flex-col">
            {/* Header */}
            <div className="bg-primary text-primary-foreground p-4 rounded-t-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary-light rounded-full flex items-center justify-center">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold">CivicBot</h3>
                    <p className="text-xs opacity-90">Always here to help</p>
                  </div>
                </div>
                <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
              </div>
            </div>

            {/* 3D Robot Placeholder */}
            <div className="bg-gradient-to-br from-primary-light to-accent p-4 flex items-center justify-center border-b">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-lg animate-bounce-soft">
                <Bot className="w-8 h-8 text-primary" />
              </div>
              <div className="ml-3 text-sm text-muted-foreground">
                <p className="font-medium">3D Robot Model</p>
                <p className="text-xs">Interactive assistant space</p>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[70%] p-3 rounded-lg text-sm ${
                      message.sender === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-foreground"
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      {message.sender === "bot" && (
                        <Bot className="w-4 h-4 mt-0.5 shrink-0" />
                      )}
                      {message.sender === "user" && (
                        <User className="w-4 h-4 mt-0.5 shrink-0" />
                      )}
                      <p>{message.content}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Replies */}
            {messages.length === 1 && (
              <div className="px-4 pb-2">
                <div className="flex flex-wrap gap-1">
                  {quickReplies.map((reply, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className="text-xs h-7"
                      onClick={() => handleQuickReply(reply)}
                    >
                      {reply}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Input */}
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Input
                  placeholder="Ask me anything..."
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  className="text-sm"
                />
                <Button
                  size="icon"
                  onClick={handleSendMessage}
                  disabled={!inputValue.trim()}
                  className="shrink-0"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
};

export default Chatbot;