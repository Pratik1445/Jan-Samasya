import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MapPin, Camera, Clock, CheckCircle, ArrowRight } from "lucide-react";

const Hero = () => {
  return (
    <section id="home" className="relative py-20 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary-light via-background to-accent opacity-50"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Hero Content */}
          <div className="animate-slide-up">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              Make Your City
              <span className="bg-gradient-to-r from-primary to-primary-hover bg-clip-text text-transparent block">
                Better Together
              </span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Report civic issues instantly with photos and location tracking. 
              Watch your community improvements come to life with real-time progress updates.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button 
                size="lg" 
                className="bg-primary hover:bg-primary-hover text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:scale-105"
              >
                <Camera className="w-5 h-5 mr-2" />
                Report an Issue
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline" 
                className="text-lg px-8 py-6 rounded-xl border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300"
              >
                <MapPin className="w-5 h-5 mr-2" />
                View City Map
              </Button>
            </div>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-6 mt-16 relative">
            {/* Highlight background glow */}
            <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-primary/10 rounded-2xl blur-xl animate-pulse-soft"></div>
            
            <Card className="relative p-6 bg-card/80 backdrop-blur-sm border-2 border-primary/20 hover:border-primary/40 hover:shadow-elegant hover:shadow-primary/20 transition-all duration-500 hover:-translate-y-2 hover:scale-105 animate-slide-up group">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary-glow rounded-lg flex items-center justify-center mb-4 mx-auto shadow-glow group-hover:shadow-primary/40 transition-all duration-300 group-hover:scale-110">
                  <Camera className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors duration-300">Quick Reporting</h3>
                <p className="text-muted-foreground group-hover:text-foreground/80 transition-colors duration-300">
                  Snap a photo, add location, and submit in seconds. Our smart system categorizes issues automatically.
                </p>
              </div>
            </Card>

            <Card className="relative p-6 bg-card/80 backdrop-blur-sm border-2 border-warning/20 hover:border-warning/40 hover:shadow-elegant hover:shadow-warning/20 transition-all duration-500 hover:-translate-y-2 hover:scale-105 animate-slide-up [animation-delay:0.1s] group">
              <div className="absolute inset-0 bg-gradient-to-br from-warning/5 to-transparent rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <div className="w-12 h-12 bg-gradient-to-br from-warning to-warning/80 rounded-lg flex items-center justify-center mb-4 mx-auto shadow-glow group-hover:shadow-warning/40 transition-all duration-300 group-hover:scale-110">
                  <Clock className="w-6 h-6 text-warning-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2 group-hover:text-warning transition-colors duration-300">Real-Time Tracking</h3>
                <p className="text-muted-foreground group-hover:text-foreground/80 transition-colors duration-300">
                  Follow your issue from submission to resolution with live status updates and notifications.
                </p>
              </div>
            </Card>

            <Card className="relative p-6 bg-card/80 backdrop-blur-sm border-2 border-success/20 hover:border-success/40 hover:shadow-elegant hover:shadow-success/20 transition-all duration-500 hover:-translate-y-2 hover:scale-105 animate-slide-up [animation-delay:0.2s] group">
              <div className="absolute inset-0 bg-gradient-to-br from-success/5 to-transparent rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <div className="w-12 h-12 bg-gradient-to-br from-success to-success/80 rounded-lg flex items-center justify-center mb-4 mx-auto shadow-glow group-hover:shadow-success/40 transition-all duration-300 group-hover:scale-110">
                  <CheckCircle className="w-6 h-6 text-success-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2 group-hover:text-success transition-colors duration-300">Community Impact</h3>
                <p className="text-muted-foreground group-hover:text-foreground/80 transition-colors duration-300">
                  See the collective impact of your community's efforts with resolution stats and improvements.
                </p>
              </div>
            </Card>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">2,543</div>
              <div className="text-muted-foreground">Issues Resolved</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-success">96%</div>
              <div className="text-muted-foreground">Resolution Rate</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-warning">24h</div>
              <div className="text-muted-foreground">Avg Response Time</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-foreground">15,892</div>
              <div className="text-muted-foreground">Active Citizens</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;