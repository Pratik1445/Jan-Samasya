import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Camera, Upload, Mic, MicOff, Send, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { saveReport } from "@/lib/firebase";
import { useAuth } from "@/lib/auth";

const ReportForm = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [location, setLocation] = useState("");
  const [category, setCategory] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [priority, setPriority] = useState<"low" | "medium" | "high" | "urgent">("medium");
  const [coords, setCoords] = useState<{ lat?: number; lng?: number }>({});
  const { toast } = useToast();
  const { uid } = useAuth();

  const handleLocationDetect = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation(`${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
          setCoords({ lat: latitude, lng: longitude });
          toast({
            title: "Location detected",
            description: "Your current location has been added to the report.",
          });
        },
        (error) => {
          toast({
            title: "Location error",
            description: "Unable to detect location. Please enter manually.",
            variant: "destructive",
          });
        }
      );
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const docId = await saveReport({
        category,
        description,
        locationText: location,
        latitude: coords.lat,
        longitude: coords.lng,
        priority,
        uid: uid || undefined,
      } as any);
      setIsSubmitted(true);
      toast({
        title: "Report submitted successfully!",
        description: `Your issue has been received. ID: ${docId}`,
      });
      setTimeout(() => setIsSubmitted(false), 3000);
      setCategory("");
      setDescription("");
      setLocation("");
      setCoords({});
      setPriority("medium");
    } catch (error: any) {
      // Surface full error for debugging Firestore rules/auth issues
      // eslint-disable-next-line no-console
      console.error("Firestore addDoc error", error?.code, error?.message, error);
      toast({
        title: "Failed to submit report",
        description: error?.message || "Please try again.",
        variant: "destructive",
      });
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    toast({
      title: isRecording ? "Recording stopped" : "Recording started",
      description: isRecording ? "Voice note saved" : "Speak your message now",
    });
  };

  if (isSubmitted) {
    return (
      <section id="report" className="py-16">
        <div className="container mx-auto px-4">
          <Card className="max-w-md mx-auto text-center animate-scale-in">
            <CardContent className="pt-8 pb-6">
              <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-success-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Report Submitted!</h3>
              <p className="text-muted-foreground mb-4">
                Your issue has been received and assigned ID: <strong>#CIV-2024-001</strong>
              </p>
              <p className="text-sm text-muted-foreground">
                You'll receive notifications about progress updates.
              </p>
              <Button 
                className="mt-6" 
                onClick={() => setIsSubmitted(false)}
              >
                Submit Another Report
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    );
  }

  return (
    <section id="report" className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4">Report a Civic Issue</h2>
            <p className="text-muted-foreground">
              Help improve your community by reporting issues that need attention
            </p>
          </div>

          <Card className="animate-slide-up">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Camera className="w-5 h-5 mr-2 text-primary" />
                Issue Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Issue Category */}
                <div className="space-y-2">
                  <Label htmlFor="category">Issue Category *</Label>
                  <Select required value={category} onValueChange={setCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select issue type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pothole">🕳️ Potholes & Road Damage</SelectItem>
                      <SelectItem value="streetlight">💡 Streetlight Issues</SelectItem>
                      <SelectItem value="garbage">🗑️ Garbage & Sanitation</SelectItem>
                      <SelectItem value="graffiti">🎨 Graffiti & Vandalism</SelectItem>
                      <SelectItem value="sidewalk">🚶 Sidewalk Problems</SelectItem>
                      <SelectItem value="traffic">🚦 Traffic Signals</SelectItem>
                      <SelectItem value="parks">🌳 Parks & Recreation</SelectItem>
                      <SelectItem value="other">📝 Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Location */}
                <div className="space-y-2">
                  <Label htmlFor="location">Location *</Label>
                  <div className="flex gap-2">
                    <Input
                      id="location"
                      placeholder="Enter address or use GPS"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      required
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={handleLocationDetect}
                      className="shrink-0"
                    >
                      <MapPin className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Photo Upload */}
                <div className="space-y-2">
                  <Label>Photo Evidence</Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer">
                    <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground mb-2">
                      Drag and drop photos here, or click to browse
                    </p>
                    <Button type="button" variant="outline" size="sm">
                      <Camera className="w-4 h-4 mr-2" />
                      Take Photo
                    </Button>
                  </div>
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe the issue in detail..."
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>

                {/* Voice Note */}
                <div className="space-y-2">
                  <Label>Voice Note (Optional)</Label>
                  <div className="flex items-center gap-3">
                    <Button
                      type="button"
                      variant={isRecording ? "destructive" : "outline"}
                      onClick={toggleRecording}
                      className="transition-all duration-300"
                    >
                      {isRecording ? (
                        <>
                          <MicOff className="w-4 h-4 mr-2" />
                          Stop Recording
                        </>
                      ) : (
                        <>
                          <Mic className="w-4 h-4 mr-2" />
                          Record Voice Note
                        </>
                      )}
                    </Button>
                    {isRecording && (
                      <div className="flex items-center text-sm text-muted-foreground">
                        <div className="w-2 h-2 bg-urgent rounded-full mr-2 animate-pulse"></div>
                        Recording...
                      </div>
                    )}
                  </div>
                </div>

                {/* Priority */}
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority Level</Label>
                  <Select value={priority} onValueChange={(v) => setPriority(v as any)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">🟢 Low - Cosmetic issues</SelectItem>
                      <SelectItem value="medium">🟡 Medium - Standard repair</SelectItem>
                      <SelectItem value="high">🟠 High - Safety concern</SelectItem>
                      <SelectItem value="urgent">🔴 Urgent - Immediate danger</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Submit Button */}
                <Button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-primary-hover text-lg py-6 transition-all duration-300 hover:scale-105"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Submit Report
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default ReportForm;