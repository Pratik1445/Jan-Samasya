import { useEffect, useMemo, useState } from "react";
import { subscribeToReports, ReportDoc } from "@/lib/firebase";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Search, Clock, CheckCircle, AlertTriangle, MapPin, Calendar, MessageSquare } from "lucide-react";

interface Issue {
  id: string;
  title: string;
  category: string;
  status: "submitted" | "acknowledged" | "in-progress" | "resolved";
  progress: number;
  location: string;
  date: string;
  priority: "low" | "medium" | "high" | "urgent";
  updates: Array<{
    date: string;
    status: string;
    message: string;
  }>;
}

const TrackingDashboard = () => {
  const [searchId, setSearchId] = useState("");
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [reports, setReports] = useState<ReportDoc[]>([]);

  useEffect(() => {
    const unsub = subscribeToReports(setReports);
    return () => unsub();
  }, []);

  const myIssues: Issue[] = useMemo(() => {
    return reports.map((r) => ({
      id: r.id,
      title: r.description?.slice(0, 60) || r.category,
      category: r.category,
      status: (r.status as any) || "submitted",
      progress: 10,
      location: r.locationText,
      date: r.createdAt ? r.createdAt.toISOString().slice(0, 10) : "",
      priority: r.priority,
      updates: [
        { date: r.createdAt ? r.createdAt.toISOString().slice(0, 10) : "", status: "submitted", message: "Issue reported" }
      ]
    }));
  }, [reports]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved": return "success";
      case "in-progress": return "warning";
      case "acknowledged": return "secondary";
      case "submitted": return "secondary";
      default: return "secondary";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "resolved": return <CheckCircle className="w-4 h-4" />;
      case "in-progress": return <Clock className="w-4 h-4" />;
      case "acknowledged": return <MessageSquare className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "urgent";
      case "high": return "destructive";
      case "medium": return "warning";
      case "low": return "secondary";
      default: return "secondary";
    }
  };

  const handleSearch = () => {
    const found = myIssues.find(issue => issue.id.toLowerCase().includes(searchId.toLowerCase()));
    if (found) {
      setSelectedIssue(found);
    }
  };

  return (
    <section id="track" className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Track Your Reports</h2>
          <p className="text-muted-foreground">
            Monitor the progress of your civic issue reports in real-time
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          {/* Search Bar */}
          <Card className="animate-slide-up">
            <CardContent className="p-6">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Input
                    placeholder="Enter report ID (e.g., CIV-2024-001)"
                    value={searchId}
                    onChange={(e) => setSearchId(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                  />
                </div>
                <Button onClick={handleSearch} className="px-8">
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* My Issues Overview */}
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="animate-slide-in">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-3">
                  <MessageSquare className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="text-2xl font-bold text-foreground">{myIssues.length}</h3>
                <p className="text-muted-foreground">Total Reports</p>
              </CardContent>
            </Card>

            <Card className="animate-slide-in [animation-delay:0.1s]">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-warning rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Clock className="w-6 h-6 text-warning-foreground" />
                </div>
                <h3 className="text-2xl font-bold text-foreground">{myIssues.filter(i => i.status === 'in-progress').length}</h3>
                <p className="text-muted-foreground">In Progress</p>
              </CardContent>
            </Card>

            <Card className="animate-slide-in [animation-delay:0.2s]">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-success rounded-lg flex items-center justify-center mx-auto mb-3">
                  <CheckCircle className="w-6 h-6 text-success-foreground" />
                </div>
                <h3 className="text-2xl font-bold text-foreground">{myIssues.filter(i => i.status === 'resolved').length}</h3>
                <p className="text-muted-foreground">Resolved</p>
              </CardContent>
            </Card>
          </div>

          {/* Issue Details */}
          {selectedIssue ? (
            <Card className="animate-scale-in">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {selectedIssue.category === "streetlight" && "💡"}
                      {selectedIssue.category === "pothole" && "🕳️"}
                      {selectedIssue.category === "garbage" && "🗑️"}
                      {selectedIssue.title}
                    </CardTitle>
                    <p className="text-muted-foreground mt-1">ID: {selectedIssue.id}</p>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant={getStatusColor(selectedIssue.status)}>
                      {getStatusIcon(selectedIssue.status)}
                      <span className="ml-1 capitalize">{selectedIssue.status.replace('-', ' ')}</span>
                    </Badge>
                    <Badge variant={getPriorityColor(selectedIssue.priority)}>
                      {selectedIssue.priority.toUpperCase()}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Progress Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{selectedIssue.progress}%</span>
                  </div>
                  <Progress value={selectedIssue.progress} className="h-3" />
                </div>

                {/* Issue Details */}
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span>{selectedIssue.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span>Reported: {selectedIssue.date}</span>
                  </div>
                </div>

                {/* Timeline */}
                <div className="space-y-4">
                  <h4 className="font-semibold">Update Timeline</h4>
                  <div className="space-y-3">
                    {selectedIssue.updates.map((update, index) => (
                      <div key={index} className="flex gap-3">
                        <div className={`w-3 h-3 rounded-full mt-1 ${
                          update.status === 'resolved' ? 'bg-success' :
                          update.status === 'in-progress' ? 'bg-warning' :
                          'bg-secondary'
                        }`}></div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium capitalize">
                              {update.status.replace('-', ' ')}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {update.date}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {update.message}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            /* My Issues List */
            <div className="space-y-4">
              <h3 className="text-xl font-semibold">My Recent Reports</h3>
              {myIssues.map((issue, index) => (
                <Card 
                  key={issue.id} 
                  className={`cursor-pointer hover:shadow-lg transition-all duration-300 animate-slide-up`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                  onClick={() => setSelectedIssue(issue)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">
                          {issue.category === "streetlight" && "💡"}
                          {issue.category === "pothole" && "🕳️"}
                          {issue.category === "garbage" && "🗑️"}
                        </span>
                        <div>
                          <h4 className="font-medium">{issue.title}</h4>
                          <p className="text-sm text-muted-foreground">ID: {issue.id}</p>
                        </div>
                      </div>
                      <Badge variant={getStatusColor(issue.status)}>
                        {getStatusIcon(issue.status)}
                        <span className="ml-1 capitalize">{issue.status.replace('-', ' ')}</span>
                      </Badge>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{issue.progress}%</span>
                      </div>
                      <Progress value={issue.progress} className="h-2" />
                    </div>

                    <div className="flex items-center justify-between mt-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {issue.location}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {issue.date}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {selectedIssue && (
            <div className="text-center">
              <Button 
                variant="outline" 
                onClick={() => setSelectedIssue(null)}
              >
                Back to All Reports
              </Button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default TrackingDashboard;