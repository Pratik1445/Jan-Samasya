import Header from "@/components/Header";
import TrackingDashboard from "@/components/TrackingDashboard";

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8 animate-fade-in">
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
              Track Your Reports
            </h1>
            <p className="text-lg text-muted-foreground">
              Monitor the progress of your submitted civic issues and see community impact
            </p>
          </div>
          <div className="animate-slide-up [animation-delay:0.2s]">
            <TrackingDashboard />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;