import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Chatbot from "@/components/Chatbot";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, FileText, BarChart3 } from "lucide-react";
import { Link } from "react-router-dom";

const Index = () => {
  const features = [
    {
      icon: FileText,
      title: "Report Issues",
      description: "Quickly report civic issues with photos and location data",
      link: "/report",
      color: "from-blue-500 to-blue-600",
    },
    {
      icon: MapPin,
      title: "Community Map",
      description: "View and explore reported issues across your city",
      link: "/map",
      color: "from-green-500 to-green-600",
    },
    {
      icon: BarChart3,
      title: "Track Progress",
      description: "Monitor the status and resolution of your reports",
      link: "/dashboard",
      color: "from-purple-500 to-purple-600",
    },
  ];

  // Removed stats section

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        
        {/* Features Section */}
        <section className="py-20 bg-gradient-to-b from-background to-muted/20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16 animate-fade-in">
              <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
                Empower Your Community
              </h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Discover powerful tools designed to make civic engagement simple, effective, and impactful
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8 mb-20">
              {features.map((feature, index) => (
                <Link
                  key={feature.title}
                  to={feature.link}
                  className={`group animate-slide-up [animation-delay:${index * 0.1}s]`}
                >
                  <Card className="h-full transition-all duration-300 hover:shadow-elegant hover:-translate-y-2 hover:scale-105 border-2 hover:border-primary/20 bg-gradient-to-br from-card to-card/80 backdrop-blur-sm">
                    <CardContent className="p-8 text-center">
                      <div className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-r ${feature.color} flex items-center justify-center shadow-glow animate-pulse-soft`}>
                        <feature.icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold mb-4 group-hover:text-primary transition-colors">
                        {feature.title}
                      </h3>
                      <p className="text-muted-foreground mb-6 leading-relaxed">
                        {feature.description}
                      </p>
                      <Button 
                        variant="outline" 
                        className="group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300 border-2 hover:shadow-md"
                      >
                        Get Started
                      </Button>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            {/* Stats Section removed as requested */}
          </div>
        </section>
      </main>
      <Chatbot />
      {/* Footer removed as requested */}
    </div>
  );
};

export default Index;