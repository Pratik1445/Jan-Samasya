import Header from "@/components/Header";
import CityMap from "@/components/CityMap";

const Map = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8 animate-fade-in">
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
              Community Issues Map
            </h1>
            <p className="text-lg text-muted-foreground">
              Explore reported issues across the city and track their resolution status
            </p>
          </div>
          <div className="animate-slide-up [animation-delay:0.2s]">
            <CityMap />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Map;