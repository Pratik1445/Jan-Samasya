import Header from "@/components/Header";
import ReportForm from "@/components/ReportForm";

const Report = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8 animate-fade-in">
              <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
                Report a Civic Issue
              </h1>
              <p className="text-lg text-muted-foreground">
                Help improve your community by reporting issues that need attention
              </p>
            </div>
            <div className="animate-slide-up [animation-delay:0.2s]">
              <ReportForm />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Report;